# Techhub Codebase

Mobile-Friendly, GitHub-based backend

## How to Use:
1. Clone repo
2. Rename `.env.example` to `.env`
3. Run `npm install`
4. Run `npm start`